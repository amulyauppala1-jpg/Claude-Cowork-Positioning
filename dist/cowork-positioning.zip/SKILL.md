---
name: cowork-positioning
description: >-
  The Cowork positioning system. Build any GTM asset — one-pager, landing page,
  deck, email, outreach sequence, blog post, battlecard, champion pitch,
  campaign set — for a named buyer (CFO, CMO, CRO, CHRO, General Counsel),
  grounded in embedded positioning, persona and brand files. Also prepares a
  seller for a specific meeting, and pressure-tests a draft in character. Use
  whenever someone mentions Cowork positioning, names one of those buyers or
  their function, asks for GTM or marketing or sales material, or says anything
  like "I need to use the Cowork positioning" or "prep me for this meeting."
---

# Cowork Positioning


# Start here

The person using this probably does not know how the repo is organized, and
should not have to. **Your job is to turn a vague request into the right asset,
asking as little as possible.**

## Step 1 — Orient yourself first, silently

Read `reference/README.md` from this skill's own bundled files, then list what
actually exists: the personas in `reference/personas/`, and the asset
instructions in `reference/skills/`. Everything is embedded — there is nothing
to clone and no connector to configure.

Do not narrate this. The person asked for help, not a status report.

## Step 2 — Work out what they need

You need three things. **Infer whatever you can from what they already said and
only ask for the rest.** If they said "landing page for a CFO," you have two of
three — ask one question, not three.

### Who is the audience?

If they named a role or a function, map it and move on. Otherwise ask, in plain
language — no jargon, no file names:

> Who's this for?
> - **Finance** — CFO, or anyone signing off on the spend
> - **Marketing** — CMO and their team
> - **Sales** — CRO, revenue leaders
> - **People / HR** — CHRO
> - **Legal** — General Counsel
> - Not sure / general audience

"Not sure" is a legitimate answer: build the function-agnostic version from
`products/` and say that is what you did.

### What do they need to make?

Map plain words to skills. Someone saying "something to send before a meeting"
means a one-pager; "something for the website" means a landing page.

| They say | Skill |
|---|---|
| one-pager, overview, leave-behind, something to send | `persona-one-pager` |
| landing page, web page, site copy, hero | `landing-page` |
| deck, slides, pitch, presentation, narrative | `pitch-and-narrative-deck` |
| email, campaign, nurture, ad, banner | `campaign-email` |
| outreach, sequence, cadence, prospecting, follow-ups | `sales-outreach-sequence` |
| blog, article, thought leadership, post | `blog-post` |
| battlecard, competitor, "how we win against" | `competitive-battlecard` |
| something they can take to their boss / their team | `internal-champion-pitch` |
| check this, review, test, is this on-message | `roleplay-tester` |
| a meeting, call, demo, named account, "prep me" | `deal-prep` |
| a campaign, launch, "everything I need for" | `campaign-kit` |

If nothing matches, ask what they'd do with it rather than listing options.
The use tells you the format.

**Two requests aren't asset requests, and they're easy to misroute:**

- **A meeting or a named account** — "I have a CFO call Thursday" is not a
  request for a one-pager. They want to walk in ready. Route to `deal-prep`,
  which produces a briefing, not something to send.
- **Several assets for one audience** — route to `campaign-kit`, not three
  separate skills. Run separately they each lead with a different argument and
  read as unrelated; `campaign-kit` fixes one spine across the set.

### One team, or the whole company?

The question that changes the answer most, and the one nobody will volunteer.
Ask it in plain English — **never say "motion":**

> Is this for one team buying it for themselves, or a company-wide rollout?

It matters because it flips which argument leads. "One vendor for everyone" is
the strongest pitch to a CFO buying company-wide and close to irrelevant to a
CMO buying for forty people. If they don't know, assume **one team** — the more
common case — and say which you assumed.

## Step 3 — Say what you can't do, before you start

Check the persona file for `TODO(source)` gaps that affect this request and
**raise them now rather than at the end.** The two that bite most often:

- **Pricing.** There is no pricing content. Anything needing a number will say
  so instead of estimating.
- **Named competitors.** There is category-level differentiation but no
  competitor files, so a battlecard against a specific competitor can't be
  built without inventing it.

One sentence, not a disclaimer paragraph. Then carry on.

## Step 4 — Hand off

Read `reference/skills/<name>.md` and follow it exactly. Those files carry the
grounding rules, format conventions and reporting requirements. Ground every
claim in `reference/products/cowork-enterprise.md`, rank using the persona file,
and apply `reference/brand/README.md`.

## Step 5 — Offer the check

After delivering, offer once:

> Want me to pressure-test this? I can read it as that buyer would and tell you
> where it falls down.

That runs `roleplay-tester`. It is the difference between output someone hopes
is right and output that has been checked, and most people won't know to ask.

## Tone

Be brief. Someone who asks for a one-pager wants a one-pager, not an education
in the positioning system. Explain the structure only if they ask.

Two things worth saying once, in passing, when relevant:

- If the positioning file is `status: draft`, say so — it means the language
  is still being signed off.
- If you led with a different argument than they expected, say why in one line.
  That's how they learn the system is doing something, not just writing.

---

## About this bundle

Everything is embedded under `reference/` — no repository access needed.

- **Built:** 2026-09-05
- **Source commit:** `3e4e377`
- **Source:** github.com/amulyauppala1-jpg/Claude-Cowork-Positioning

**This is a snapshot, not a live read.** If the build date is more than a few
weeks old, say so when it matters — a proof point that was current at build time
may have passed its 90-day ceiling since. Re-export from the repo to refresh.
